const Layout = () => import('@/layout/index.vue')

export default {
  name: 'enjoyGift',
  path: '/',
  component: Layout,
  redirect: '/workbench',
  meta: {
    title: '天天享礼',
    icon: 'teenyicons:gift-solid',
    role: ['admin'],
    requireAuth: true,
    order: 2,
  },
  children: [
    // {
    //   name: 'Workbench1',
    //   path: 'workbench',
    //   component: () => import('@/views/enjoy-gift/workbench/index.vue'),
    //   meta: {
    //     title: '账户中心',
    //     icon: 'material-symbols:airplay-rounded',
    //     order: 0,
    //   },
    // },
    {
      name: 'TaskMangeList',
      path: 'taskMange/list',
      component: () => import('@/views/enjoy-gift/task-mange/index.vue'),
      meta: {
        title: '任务列表',
        icon: 'fa-solid:tasks',
        order: 96,
        keepAlive: true,
      },
    },
    {
      name: 'TimeLimitCouponList',
      path: 'timeLimitCoupon/list',
      component: () => import('@/views/enjoy-gift/time-limit-coupon/index.vue'),
      meta: {
        title: '限时领券',
        icon: 'ic:twotone-access-time-filled',
        order: 97,
        keepAlive: true,
      },
    },
    {
      name: 'TimeLimitSeckillList',
      path: 'list',
      component: () => import('@/views/enjoy-gift/time-limit-seckill/index.vue'),
      meta: {
        title: '限时秒杀',
        icon: 'material-symbols:timer',
        order: 98,
        keepAlive: true,
      },
    },
    {
      name: 'CouponList',
      path: 'coupon/list',
      component: () => import('@/views/enjoy-gift/coupon-list/index.vue'),
      meta: {
        title: '优惠券列表',
        icon: 'ri:coupon-3-fill',
        keepAlive: true,
        order: 99,
      },
    },
    {
      name: 'GoodsList',
      path: 'goods/list',
      component: () => import('@/views/enjoy-gift/goods-list/index.vue'),
      meta: {
        title: '商品列表',
        icon: 'ep:goods-filled',
        order: 100,
        keepAlive: true,
      },
    },

    {
      name: 'CouponGroup',
      path: 'couponGroup/list',
      component: () => import('@/views/enjoy-gift/coupon-group/index.vue'),
      meta: {
        title: '优惠券分组',
        icon: 'uis:grid',
        keepAlive: true,
        order: 101,
      },
    },
    {
      name: 'CarouselManage',
      path: 'carousel-manage/list',
      component: () => import('@/views/enjoy-gift/carousel-manage/index.vue'),
      meta: {
        title: '轮播管理',
        icon: 'material-symbols:code-blocks-rounded',
        keepAlive: true,
        order: 102,
      },
    },

    {
      name: 'RankingList',
      path: 'ranking/list',
      component: () => import('@/views/enjoy-gift/ranking-list/index.vue'),
      meta: {
        title: '排行榜管理',
        icon: 'fa6-regular:chart-bar',
        keepAlive: true,
        order: 103,
      },
    },
    {
      name: 'SingleColumnDiagram',
      path: 'singleColumnDiagram',
      component: () => import('@/views/enjoy-gift/single-column-diagram/index.vue'),
      meta: {
        title: '单例图',
        icon: 'fa6-regular:image',
        keepAlive: true,
        order: 104,
      },
    },
    {
      name: 'OrderList',
      path: 'orderMange/list',
      component: () => import('@/views/enjoy-gift/order-manage/index.vue'),
      meta: {
        title: '订单列表',
        icon: 'icon-park-solid:align-text-both-one',
        order: 105,
        keepAlive: true,
      },
    },

    // {
    //   name: 'coupon-group',
    //   path: 'couponGroup',
    //   component: Layout,
    //   redirect: '/couponGroup/list',
    //   meta: {
    //     title: '优惠券分组',
    //     order: 101,
    //   },
    //   children: [
    //     {
    //       name: 'CouponGroup',
    //       path: 'list',
    //       component: () => import('@/views/coupon-group/index.vue'),
    //       meta: {
    //         title: '优惠券分组',
    //         icon: 'uis:grid',
    //         keepAlive: true,
    //       },
    //     },
    //   ],
    // },
  ],
}
