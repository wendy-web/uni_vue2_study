const Layout = () => import('@/layout/index.vue')

export default {
  name: 'smallStoreDiscount',
  path: '/small-store-discount',
  component: Layout,
  //   redirect: '/orderMange/list',
  meta: {
    title: '小店有惠',
    icon: 'icon-park-outline:shop',
    role: ['admin'],
    requireAuth: true,
    order: 5,
  },
  children: [
    {
      name: 'productRecommend',
      path: 'product-recommend',
      component: () => import('@/views/small-store-discount/product-recommend/index.vue'),
      meta: {
        title: '商品推荐',
        icon: 'ep:goods-filled',
        order: 15,
      },
    },
    {
      name: 'taskManage',
      path: 'task-manage',
      component: () => import('@/views/small-store-discount/task-manage/index.vue'),
      meta: {
        title: '任务管理',
        icon: 'fluent-mdl2:task-manager',
        order: 15,
        role: ['admin'],
      },
      children: [
        {
          name: 'taskList',
          path: 'task-list',
          component: () => import('@/views/small-store-discount/task-manage/task-list/index.vue'),
          meta: {
            title: '任务列表',
            icon: 'ic:baseline-menu',
            role: ['admin'],
          },
        },
      ],
    },
    {
      name: 'marketActivitie',
      path: 'market-activitie',
      component: () => import('@/views/small-store-discount/market-activitie/index.vue'),
      meta: {
        title: '营销活动',
        icon: 'jam:task-list-f',
        order: 15,
        role: ['admin'],
      },
      children: [
        {
          name: 'luckyDraw',
          path: 'lucky-draw',
          component: () => import('@/views/small-store-discount/market-activitie/lucky-draw/index.vue'),
          meta: {
            title: '幸运抽奖',
            icon: 'tabler:award-filled',
            role: ['admin'],
          },
        },
      ],
    },
    {
      name: 'goodsManage',
      path: 'goods-manage',
      component: () => import('@/views/small-store-discount/goods-manage/index.vue'),
      meta: {
        title: '商品管理',
        icon: 'icon-park-solid:commodity',
        order: 15,
        role: ['admin'],
      },
      children: [
        {
          name: 'goodsList',
          path: 'goods-list',
          component: () => import('@/views/small-store-discount/goods-manage/goods-list/index.vue'),
          meta: {
            title: '商品列表',
            icon: 'ri:file-list-line',
            role: ['admin'],
          },
        },
        {
          name: 'goodsGroup',
          path: 'goods-group',
          component: () => import('@/views/small-store-discount/goods-manage/goods-group/index.vue'),
          meta: {
            title: '商品分组',
            icon: 'fluent-mdl2:hard-drive-group',
            role: ['admin'],
          },
        },
      ],
    },
    {
      name: 'orderManage',
      path: 'order-manage',
      component: () => import('@/views/small-store-discount/order-manage/index.vue'),
      meta: {
        title: '订单管理',
        icon: 'material-symbols:border-all-rounded',
        order: 15,
        role: ['admin'],
      },
      children: [
        {
          name: 'orderList',
          path: 'order-list',
          component: () => import('@/views/small-store-discount/order-manage/order-list/index.vue'),
          meta: {
            title: '订单列表',
            icon: 'mdi:order-alphabetical-descending',
            role: ['admin'],
          },
        },
      ],
    },
  ],
}
